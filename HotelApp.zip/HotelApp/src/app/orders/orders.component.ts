import { Component, OnInit } from '@angular/core';
import { OrderService } from '../shared/order.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

  orderList;
  constructor(private ordersservice: OrderService, private router: Router,
    private toastr: ToastrService) { }

  ngOnInit() {

    this.refreshlist();
  }

  refreshlist() {
    this.ordersservice.GetOrderList().then(res => this.orderList = res);
  }

  OpenForEditOrder(OrderID: number) {
    this.router.navigate(['/order/edit/' + OrderID]);
  }

  OrderDelete(id: number) {
    if (confirm("Are you sure you want to delete this order ?")) {
      this.ordersservice.deleteorder(id).then(res => {
        this.refreshlist();
        this.toastr.warning("Deleted Successfully", "Restaurant App");
      });
    }
  }

}

