import { Injectable } from '@angular/core';
import { Order } from './order.model';
import { OrderItem } from './order-item.model';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  formData: Order;
  orderItems: OrderItem[];
  Url: string = 'http://localhost:56328/api';
  constructor(private http: HttpClient) { }

  saveorupdateorder() {
    var body = {
      ...this.formData,
      OrderItems: this.orderItems
    }
    return this.http.post(this.Url + '/Order', body);
  }

  GetOrderList ()
  {
    return this.http.get(this.Url + '/Order').toPromise();
  }

  GetOrderById (id : number) : any 
  {
    return this.http.get(this.Url + '/Order/' + id).toPromise();
  }

  deleteorder (id : number)
  {
    return this.http.delete(this.Url + '/Order/' + id).toPromise();
  }


}
