import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  apiUrl: string = 'http://localhost:56328/api';

  constructor(private http: HttpClient) { }

  GetCustomerList() {
    return this.http.get(this.apiUrl + '/Customer').toPromise();
  }
}
