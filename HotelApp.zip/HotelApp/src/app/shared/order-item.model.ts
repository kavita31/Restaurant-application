export class OrderItem {
     OrderItemID  : number
    OrderID : number
    ItemID : number
   Quantity : number
   ItemName: string
   Price : number
   Total : number
}
