export class Item {
  ItemID : number
  Name : string
  Price: number
}
