import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ItemService {
  url: string = 'http://localhost:56328/api';

  constructor(private http: HttpClient) { }

  getitem() {
    return this.http.get(this.url + '/Item').toPromise();
  }
}
